/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0A0D0C',
        surface: '#121715',
        surface2: '#171D1B',
        line: '#242E2B',
        copper: {
          DEFAULT: '#C9814C',
          light: '#E0A374',
          dim: '#8A5A35',
        },
        signal: {
          DEFAULT: '#4FD1C0',
          light: '#7EE6D8',
          dim: '#2D7A6F',
        },
        paper: '#EDEAE3',
        muted: '#8B948F',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      backgroundImage: {
        grid: 'linear-gradient(rgba(201,129,76,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(201,129,76,0.06) 1px, transparent 1px)',
      },
    },
  },
  plugins: [],
}
