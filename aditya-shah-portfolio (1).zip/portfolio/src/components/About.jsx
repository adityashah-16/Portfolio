import React from 'react'

export default function About() {
  return (
    <section id="about" className="py-24 px-6 border-t border-line">
      <div className="max-w-6xl mx-auto grid md:grid-cols-[1fr_2fr] gap-10">
        <div>
          <p className="eyebrow mb-3">01 — About</p>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold">
            Two disciplines, one way of thinking.
          </h2>
        </div>
        <div className="space-y-5 text-muted leading-relaxed text-base sm:text-lg">
          <p>
            I'm currently in my final year of a B.Tech in Electronics &amp;
            Telecommunication Engineering at Yeshwantrao Chavan College of
            Engineering, Nagpur, graduating in 2027 with a CGPA of 8.01 (through
            6th semester).
          </p>
          <p>
            My core strength is Java — data structures and algorithms,
            object-oriented design, and building full applications with JDBC
            and MySQL behind them. Alongside that, my engineering background
            means I'm just as comfortable with embedded systems: ESP32,
            Arduino, sensors, and the IoT layer that connects hardware to
            software.
          </p>
          <p>
            I got hands-on industrial exposure interning at Active Controls in
            Nagpur, working with PLCs, SCADA systems, and VFD motor control —
            which sharpened how I think about systems that have to work
            reliably in the real world, not just in a demo.
          </p>
          <p>
            I'm looking for a Software Engineer role where I can keep building
            things that are both technically solid and genuinely useful.
          </p>
        </div>
      </div>
    </section>
  )
}
