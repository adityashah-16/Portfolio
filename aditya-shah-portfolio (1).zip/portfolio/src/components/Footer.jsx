import React from 'react'
import { Github, Linkedin, Mail } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="border-t border-line py-10 px-6">
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="font-mono text-xs text-muted">
          © {new Date().getFullYear()} Aditya Shah. Built with React &amp; Tailwind.
        </p>
        <div className="flex items-center gap-5">
          <a href="https://linkedin.com/in/adityashah16" target="_blank" rel="noreferrer" aria-label="LinkedIn" className="text-muted hover:text-signal transition-colors">
            <Linkedin size={16} />
          </a>
          <a href="#" aria-label="GitHub (add your profile URL)" className="text-muted hover:text-signal transition-colors">
            <Github size={16} />
          </a>
          <a href="mailto:adiityaashah@gmail.com" aria-label="Email" className="text-muted hover:text-signal transition-colors">
            <Mail size={16} />
          </a>
        </div>
      </div>
    </footer>
  )
}
