import React, { useState, useEffect } from 'react'
import { Menu, X, Download } from 'lucide-react'

const LINKS = [
  { href: '#about', label: 'About' },
  { href: '#skills', label: 'Skills' },
  { href: '#experience', label: 'Experience' },
  { href: '#projects', label: 'Projects' },
  { href: '#education', label: 'Education' },
  { href: '#contact', label: 'Contact' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-colors duration-300 ${
        scrolled ? 'bg-ink/90 backdrop-blur border-b border-line' : 'bg-transparent'
      }`}
    >
      <nav className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <a href="#top" className="font-display font-semibold text-lg tracking-tight">
          Aditya<span className="text-copper">.</span>Shah
        </a>

        <ul className="hidden md:flex items-center gap-8 font-body text-sm text-muted">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="hover:text-paper transition-colors">
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <a
          href="/Aditya_Shah_Resume.pdf"
          download
          className="hidden md:inline-flex items-center gap-2 border border-copper text-copper text-sm font-mono px-4 py-2 rounded hover:bg-copper hover:text-ink transition-colors"
        >
          <Download size={14} /> Resume
        </a>

        <button
          className="md:hidden text-paper"
          onClick={() => setOpen(!open)}
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {open && (
        <div className="md:hidden bg-ink border-t border-line px-6 py-4 flex flex-col gap-4">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="text-paper text-sm font-body"
            >
              {l.label}
            </a>
          ))}
          <a
            href="/Aditya_Shah_Resume.pdf"
            download
            className="inline-flex items-center gap-2 border border-copper text-copper text-sm font-mono px-4 py-2 rounded w-fit"
          >
            <Download size={14} /> Resume
          </a>
        </div>
      )}
    </header>
  )
}
