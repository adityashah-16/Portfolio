import React from 'react'

// Signature element: an oscilloscope-style signal trace that "resolves" into
// steady state — a visual metaphor for turning irregular input (wave energy,
// noise, raw signals) into usable, structured output. Ties to Aditya's
// electronics background and his Wave Energy Converter project.
export default function Waveform({ className = '' }) {
  return (
    <svg
      viewBox="0 0 900 220"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="waveGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#C9814C" />
          <stop offset="55%" stopColor="#C9814C" />
          <stop offset="100%" stopColor="#4FD1C0" />
        </linearGradient>
      </defs>

      {/* baseline grid ticks */}
      {Array.from({ length: 18 }).map((_, i) => (
        <line
          key={i}
          x1={i * 52}
          y1="0"
          x2={i * 52}
          y2="220"
          stroke="#242E2B"
          strokeWidth="1"
        />
      ))}

      {/* irregular -> resolving waveform */}
      <path
        d="M0,110
           C20,60 40,160 60,100
           C90,20 110,190 140,90
           C170,10 200,180 230,110
           C260,50 285,150 310,100
           C340,150 360,60 390,110
           C420,90 440,120 470,108
           C520,100 560,112 610,108
           C660,106 700,110 750,109
           C800,109 850,109 900,109"
        stroke="url(#waveGrad)"
        strokeWidth="2.5"
        strokeLinecap="round"
        className="wave-path"
      />

      {/* resolved steady segment marker */}
      <circle cx="750" cy="109" r="4" fill="#4FD1C0" />
      <circle cx="750" cy="109" r="9" stroke="#4FD1C0" strokeOpacity="0.4" fill="none">
        <animate attributeName="r" values="9;16;9" dur="2.4s" repeatCount="indefinite" />
        <animate attributeName="stroke-opacity" values="0.4;0;0.4" dur="2.4s" repeatCount="indefinite" />
      </circle>

      <style>{`
        .wave-path {
          stroke-dasharray: 1400;
          stroke-dashoffset: 1400;
          animation: draw 2.4s ease-out forwards;
        }
        @keyframes draw {
          to { stroke-dashoffset: 0; }
        }
        @media (prefers-reduced-motion: reduce) {
          .wave-path { animation: none; stroke-dashoffset: 0; }
        }
      `}</style>
    </svg>
  )
}
