import React from 'react'

export default function Experience() {
  return (
    <section id="experience" className="py-24 px-6 border-t border-line">
      <div className="max-w-6xl mx-auto">
        <p className="eyebrow mb-3">03 — Experience</p>
        <h2 className="font-display text-2xl sm:text-3xl font-semibold mb-12">
          Where I've worked.
        </h2>

        <div className="card p-7 sm:p-9 trace-hover max-w-3xl">
          <div className="flex flex-wrap items-baseline justify-between gap-2 mb-4">
            <h3 className="font-display text-xl font-semibold">
              Summer Intern — Active Controls, Nagpur
            </h3>
            <span className="font-mono text-xs text-signal">Industrial Automation</span>
          </div>
          <ul className="space-y-2.5 text-muted leading-relaxed">
            <li className="flex gap-3">
              <span className="text-copper mt-1.5">▸</span>
              Worked on industrial automation and instrumentation systems, including PLC programming and SCADA-based monitoring.
            </li>
            <li className="flex gap-3">
              <span className="text-copper mt-1.5">▸</span>
              Assisted with control panel wiring and configuration for VFD-driven motor control setups.
            </li>
            <li className="flex gap-3">
              <span className="text-copper mt-1.5">▸</span>
              Gained hands-on exposure to sensor integration and real-world control systems in a live industrial environment.
            </li>
          </ul>
        </div>
      </div>
    </section>
  )
}
