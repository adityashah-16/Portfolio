import React from 'react'

const GROUPS = [
  {
    label: 'Languages & Core CS',
    items: ['Java', 'SQL', 'Data Structures & Algorithms', 'OOP', 'DBMS', 'Problem Solving'],
  },
  {
    label: 'Database',
    items: ['MySQL', 'RDBMS', 'JDBC'],
  },
  {
    label: 'Embedded & IoT',
    items: ['ESP32', 'ESP8266', 'Arduino', 'Embedded C', 'GSM', 'GPS', 'Sensors', 'Blynk IoT'],
  },
  {
    label: 'Industrial Automation',
    items: ['PLC', 'SCADA', 'VFD Motor Control', 'Control Panels'],
  },
]

export default function Skills() {
  return (
    <section id="skills" className="py-24 px-6 border-t border-line">
      <div className="max-w-6xl mx-auto">
        <p className="eyebrow mb-3">02 — Skills</p>
        <h2 className="font-display text-2xl sm:text-3xl font-semibold mb-12">
          What I build with.
        </h2>

        <div className="grid sm:grid-cols-2 gap-6">
          {GROUPS.map((g) => (
            <div key={g.label} className="card p-6 trace-hover">
              <h3 className="font-mono text-xs tracking-wider uppercase text-copper mb-4">
                {g.label}
              </h3>
              <div className="flex flex-wrap gap-2">
                {g.items.map((item) => (
                  <span
                    key={item}
                    className="font-mono text-xs px-3 py-1.5 rounded border border-line text-paper/90"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
