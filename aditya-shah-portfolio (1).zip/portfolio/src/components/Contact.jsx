import React, { useState } from 'react'
import { Mail, Phone, Linkedin, Send } from 'lucide-react'

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [sent, setSent] = useState(false)

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = (e) => {
    e.preventDefault()
    // Frontend-only for now — wire this up to a backend or a service
    // like Formspree / EmailJS when ready.
    setSent(true)
  }

  return (
    <section id="contact" className="py-24 px-6 border-t border-line">
      <div className="max-w-6xl mx-auto grid md:grid-cols-[1fr_1.3fr] gap-14">
        <div>
          <p className="eyebrow mb-3">07 — Contact</p>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold mb-6">
            Let's talk.
          </h2>
          <p className="text-muted leading-relaxed mb-8 max-w-sm">
            Open to Software Engineer roles, internships, and anything at the
            intersection of software and embedded systems. Reach out directly
            or use the form.
          </p>

          <div className="space-y-4">
            <a href="mailto:adiityaashah@gmail.com" className="flex items-center gap-3 text-sm text-paper/90 hover:text-signal transition-colors w-fit">
              <Mail size={17} className="text-copper" /> adiityaashah@gmail.com
            </a>
            <a href="tel:+917970858502" className="flex items-center gap-3 text-sm text-paper/90 hover:text-signal transition-colors w-fit">
              <Phone size={17} className="text-copper" /> +91 79708 58502
            </a>
            <a href="https://linkedin.com/in/adityashah16" target="_blank" rel="noreferrer" className="flex items-center gap-3 text-sm text-paper/90 hover:text-signal transition-colors w-fit">
              <Linkedin size={17} className="text-copper" /> linkedin.com/in/adityashah16
            </a>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="card p-7 sm:p-9 space-y-5">
          <div>
            <label htmlFor="name" className="font-mono text-xs text-muted uppercase tracking-wide">Name</label>
            <input
              id="name" name="name" type="text" required
              value={form.name} onChange={handleChange}
              className="mt-2 w-full bg-surface2 border border-line rounded px-4 py-2.5 text-sm text-paper focus:outline-none focus:border-signal transition-colors"
              placeholder="Your name"
            />
          </div>
          <div>
            <label htmlFor="email" className="font-mono text-xs text-muted uppercase tracking-wide">Email</label>
            <input
              id="email" name="email" type="email" required
              value={form.email} onChange={handleChange}
              className="mt-2 w-full bg-surface2 border border-line rounded px-4 py-2.5 text-sm text-paper focus:outline-none focus:border-signal transition-colors"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label htmlFor="message" className="font-mono text-xs text-muted uppercase tracking-wide">Message</label>
            <textarea
              id="message" name="message" required rows={4}
              value={form.message} onChange={handleChange}
              className="mt-2 w-full bg-surface2 border border-line rounded px-4 py-2.5 text-sm text-paper focus:outline-none focus:border-signal transition-colors resize-none"
              placeholder="What's on your mind?"
            />
          </div>
          <button
            type="submit"
            className="inline-flex items-center gap-2 bg-copper text-ink font-medium text-sm px-5 py-3 rounded hover:bg-copper-light transition-colors"
          >
            Send message <Send size={15} />
          </button>
          {sent && (
            <p className="font-mono text-xs text-signal">
              Message captured locally — connect a backend (Formspree, EmailJS, etc.) to actually deliver it.
            </p>
          )}
        </form>
      </div>
    </section>
  )
}
