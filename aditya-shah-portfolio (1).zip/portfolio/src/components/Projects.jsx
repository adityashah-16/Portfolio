import React from 'react'
import { Zap, HeartPulse, LockKeyhole, Volume2 } from 'lucide-react'

const PROJECTS = [
  {
    icon: Zap,
    title: 'Wave Energy Converter for Coastal Areas',
    tag: 'Major Project',
    stack: 'Stepper Motor · ESP8266 · Renewable Energy · IoT',
    points: [
      'Converts ocean wave motion into electrical energy via a floating buoy and rack-and-pinion mechanism that turns vertical wave movement into rotational motion.',
      'Studied 30+ research papers before choosing a stepper motor specifically for its ability to handle irregular wave motion.',
      'Integrated a bridge rectifier, battery management system, and ESP8266 for real-time system monitoring.',
    ],
  },
  {
    icon: HeartPulse,
    title: 'Hospital Management System',
    tag: 'Java · JDBC · MySQL',
    stack: 'CRUD · Authentication · RBAC',
    points: [
      'Built a system to manage patients, doctors, and appointments with full CRUD operations.',
      'Implemented user authentication and role-based access control (RBAC) for secure access.',
      'Designed and optimized a relational database schema with efficient SQL queries.',
    ],
  },
  {
    icon: LockKeyhole,
    title: 'IoT-Based Smart Lock System',
    tag: 'ESP8266 · RFID / Bluetooth',
    stack: 'Embedded Security',
    points: [
      'Developed a smart lock system with password, RFID, and Bluetooth-based authentication.',
      'Designed modular embedded code with clean hardware interfacing.',
    ],
  },
  {
    icon: Volume2,
    title: 'IoT Sound Pollution Monitoring',
    tag: 'ESP8266 · Blynk IoT',
    stack: '16×2 LCD · Real-time Dashboard',
    points: [
      'Built a real-time noise level monitoring system using ESP8266 and the Blynk IoT platform.',
      'Streamed sound level data to a mobile dashboard for live tracking.',
      'A cost-effective solution aimed at homes, classrooms, labs, and public spaces.',
    ],
  },
]

export default function Projects() {
  return (
    <section id="projects" className="py-24 px-6 border-t border-line">
      <div className="max-w-6xl mx-auto">
        <p className="eyebrow mb-3">04 — Projects</p>
        <h2 className="font-display text-2xl sm:text-3xl font-semibold mb-12">
          Things I've built.
        </h2>

        <div className="grid md:grid-cols-2 gap-6">
          {PROJECTS.map((p) => {
            const Icon = p.icon
            return (
              <div key={p.title} className="card p-7 trace-hover flex flex-col">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-10 h-10 rounded-full bg-surface2 border border-line flex items-center justify-center text-signal">
                    <Icon size={18} />
                  </div>
                  <span className="font-mono text-[11px] text-copper text-right">{p.tag}</span>
                </div>
                <h3 className="font-display text-lg font-semibold mb-1">{p.title}</h3>
                <p className="font-mono text-[11px] text-muted mb-4">{p.stack}</p>
                <ul className="space-y-2 text-sm text-muted leading-relaxed">
                  {p.points.map((pt, i) => (
                    <li key={i} className="flex gap-2.5">
                      <span className="text-signal mt-1.5 shrink-0 text-[10px]">●</span>
                      {pt}
                    </li>
                  ))}
                </ul>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
