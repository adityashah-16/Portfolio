import React from 'react'
import { ArrowRight, Github, Linkedin, Mail } from 'lucide-react'
import Waveform from './Waveform.jsx'

export default function Hero() {
  return (
    <section id="top" className="relative pt-40 pb-28 px-6 overflow-hidden">
      <div className="absolute inset-0 bg-grid bg-[size:52px_52px] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_0%,black,transparent)]" />

      <div className="relative max-w-6xl mx-auto">
        <p className="eyebrow mb-5">Electronics &amp; Telecommunication Engineering · Nagpur, India</p>

        <h1 className="font-display font-semibold text-4xl sm:text-5xl md:text-6xl leading-[1.08] max-w-3xl">
          Turning raw signals into
          <span className="text-copper"> working systems.</span>
        </h1>

        <p className="mt-6 max-w-xl text-muted text-base sm:text-lg leading-relaxed">
          I'm Aditya — an ECE undergraduate at YCCE who builds across the stack:
          Java applications with real databases behind them, and embedded/IoT
          systems that turn physical signals into useful data. Currently looking
          for Software Engineer roles where I can keep doing both.
        </p>

        <div className="mt-9 flex flex-wrap items-center gap-4">
          <a
            href="#projects"
            className="inline-flex items-center gap-2 bg-copper text-ink font-body font-medium text-sm px-5 py-3 rounded hover:bg-copper-light transition-colors"
          >
            View projects <ArrowRight size={16} />
          </a>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 border border-line text-paper font-body text-sm px-5 py-3 rounded hover:border-signal hover:text-signal transition-colors"
          >
            Get in touch
          </a>

          <div className="flex items-center gap-4 ml-1">
            <a href="https://linkedin.com/in/adityashah16" target="_blank" rel="noreferrer" aria-label="LinkedIn" className="text-muted hover:text-signal transition-colors">
              <Linkedin size={19} />
            </a>
            <a href="#" aria-label="GitHub (add your profile URL)" className="text-muted hover:text-signal transition-colors">
              <Github size={19} />
            </a>
            <a href="mailto:adiityaashah@gmail.com" aria-label="Email" className="text-muted hover:text-signal transition-colors">
              <Mail size={19} />
            </a>
          </div>
        </div>

        <div className="mt-16">
          <Waveform className="w-full h-28 sm:h-36" />
          <div className="flex justify-between font-mono text-[11px] text-muted mt-2 tracking-wide">
            <span>INPUT · irregular</span>
            <span className="text-signal">OUTPUT · resolved</span>
          </div>
        </div>
      </div>
    </section>
  )
}
