import React from 'react'
import { GraduationCap, Award } from 'lucide-react'

const EDUCATION = [
  {
    school: 'Yeshwantrao Chavan College of Engineering (YCCE)',
    degree: 'B.Tech — Electronics & Telecommunication Engineering',
    meta: 'CGPA 8.01/10 (through 6th semester) · Expected May 2027',
  },
  {
    school: "St. Xavier's High School, Nagpur",
    degree: 'Higher Secondary Certificate (HSC), CBSE',
    meta: '2021 – 2023 · 65.4%',
  },
  {
    school: 'School of Scholars, Nagpur',
    degree: 'Secondary School Certificate (SSC), CBSE',
    meta: '2020 – 2021 · 76.4%',
  },
]

const CERTS = [
  'Java (Core) — Binary Brains',
  'Industry 4.0, IIoT and Digital Transformation — IETE, ASME',
  'PCB Designing — IETE, YCCE',
]

export default function Education() {
  return (
    <section id="education" className="py-24 px-6 border-t border-line">
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-14">
        <div>
          <p className="eyebrow mb-3">05 — Education</p>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold mb-10">
            Academic background.
          </h2>
          <div className="space-y-6">
            {EDUCATION.map((e) => (
              <div key={e.school} className="flex gap-4">
                <GraduationCap size={20} className="text-copper mt-1 shrink-0" />
                <div>
                  <h3 className="font-body font-semibold">{e.school}</h3>
                  <p className="text-sm text-muted">{e.degree}</p>
                  <p className="font-mono text-xs text-signal mt-1">{e.meta}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <p className="eyebrow mb-3">06 — Certifications</p>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold mb-10">
            Certifications.
          </h2>
          <div className="space-y-4">
            {CERTS.map((c) => (
              <div key={c} className="flex gap-4 items-start card p-4 trace-hover">
                <Award size={18} className="text-signal mt-0.5 shrink-0" />
                <p className="text-sm text-paper/90">{c}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
