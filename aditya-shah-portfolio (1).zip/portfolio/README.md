# Aditya Shah — Portfolio

A personal portfolio site built with React, Vite, Tailwind CSS, and Lucide icons.

## Run locally

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
```

Output goes to `dist/`. Deploy that folder to Vercel, Netlify, GitHub Pages, or any static host.

## Before you deploy

- **GitHub link**: the GitHub icons in the Hero and Footer currently point to `#`. Replace with your real profile URL in `src/components/Hero.jsx` and `src/components/Footer.jsx`.
- **Resume**: `public/Aditya_Shah_Resume.pdf` is already in place from your uploaded resume — swap it out any time you update your resume, keeping the same filename (or update the link in `src/components/Navbar.jsx`).
- **Contact form**: currently frontend-only (it just confirms locally). Wire it to a real backend — [Formspree](https://formspree.io) or [EmailJS](https://www.emailjs.com) are the fastest no-backend options — in `src/components/Contact.jsx`.

## Structure

```
src/
  components/
    Navbar.jsx      sticky nav, mobile menu, resume download
    Hero.jsx         intro + signature waveform visual
    Waveform.jsx      animated SVG signature element
    About.jsx
    Skills.jsx
    Experience.jsx
    Projects.jsx
    Education.jsx    education + certifications
    Contact.jsx
    Footer.jsx
  App.jsx
  index.css           design tokens, base styles
```
